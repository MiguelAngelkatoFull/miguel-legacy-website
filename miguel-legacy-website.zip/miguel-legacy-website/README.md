
# Legado Miguel - Sitio Web Personal

Este sitio refleja el recorrido personal y profesional de Miguel A. Ruiz Ramírez:
- Experiencia profesional en ventas, electrónica automotriz y herrería
- Transformación hacia Full Stack Developer
- Espacio para honrar sus raíces, familia y visión futura

## Estructura

- index.html: Página principal
- style.css: Estilos
- script.js: Carga de reflexiones y bitácora
- /docs: Contiene bitácora y reflexiones
- /img: Imágenes familiares y de legado
