
# Reflexiones públicas

- Agradezco mi historia.
- Honro mis raíces.
- Estoy aprendiendo a ser un mejor hombre, padre y profesional.
